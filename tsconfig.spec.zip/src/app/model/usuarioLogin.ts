export class usuarioLogin{
  public id: number
  public nome: string
  public email: string
  public senha: string
  public token: string
  public foto: string
  public tipo: string
}