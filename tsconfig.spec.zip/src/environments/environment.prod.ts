export const environment = {
  production: true,
  token: '',
  nome: '',
  id: 0,
  foto:''
};
